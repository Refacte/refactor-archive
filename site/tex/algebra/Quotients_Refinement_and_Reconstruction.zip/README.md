# Quotients, Refinement, and Reconstruction

Comparing choices, changing coordinates, and detecting what remains
Henry Shin · Revised November 3, 2026 · Tensorgami archive

These are the 16 TeX inputs for the 85-page PDF edition linked at
https://refactor.press/notes/quotients-and-reconstruction.html.
The same page contains the complete web text, with matching section and theorem numbers.

Build from this directory with a current TeX Live or MiKTeX installation:

    pdflatex -interaction=nonstopmode -halt-on-error -jobname=quotients-and-reconstruction main.tex
    pdflatex -interaction=nonstopmode -halt-on-error -jobname=quotients-and-reconstruction main.tex

The main file declares its dependencies. Repeat the second pass if cross-references change.
Fonts and TeX versions may affect pagination or PDF bytes; the site supplies the published PDF.

Published PDF SHA-256:
a626a83d33998d32e2d591ebeeebdd19fe24984a33a5491f766a2170f3815fbd

Copyright © 2026 Henry Shin. All rights reserved.
See https://refactor.press/license.html for reuse information.
